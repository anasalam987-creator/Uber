# دليل الإعداد — أوبر داشبورد المشترك

## خطوات الرفع على Render.com (مجاني)

### ١. رفع الكود على GitHub
1. افتح github.com وأنشئ حساب (مجاني)
2. اضغط "New repository" → سمّه `uber-dashboard`
3. اضغط "uploading an existing file"
4. ارفع كل ملفات هذا المجلد
5. اضغط "Commit changes"

### ٢. ربطه بـ Render
1. افتح render.com وأنشئ حساب (مجاني)
2. اضغط "New +" → "Web Service"
3. اختر الـ GitHub repo
4. الإعدادات تُملأ تلقائياً من render.yaml

### ٣. إضافة مفتاح Claude API
في إعدادات الـ Service في Render:
- اضغط "Environment"
- أضف: `ANTHROPIC_API_KEY` = مفتاحك من console.anthropic.com

### ٤. شارك الرابط
بعد النشر ستحصل على رابط مثل:
`https://uber-dashboard.onrender.com`
شاركه مع المجموعة — كل شخص يفتحه ويرفع صوره!

## ملاحظات
- قاعدة البيانات تُخزّن على نفس السيرفر
- كل الأعضاء يرون نفس البيانات
- يتحدث تلقائياً كل 30 ثانية
